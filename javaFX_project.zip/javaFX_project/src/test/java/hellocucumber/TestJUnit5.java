package hellocucumber;

import static org.junit.jupiter.api.Assertions.assertTrue;

import org.junit.jupiter.api.Test;

public class TestJUnit5 {
	@Test
	public void testJUnit5() {
		System.out.println("JUnit 5");
		assertTrue(true);
	}

}
