package app;

/**
 * Author: Daniel
 */
public enum AbsenceType {
    VACATION,
    SICKNESS,
    COURSE
}
